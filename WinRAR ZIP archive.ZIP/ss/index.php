<?php
include 'db.php';

$sql = "SELECT * FROM employees WHERE is_active = 1";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Management</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Работники</h1>
    <a href="create.php">Добавить нового сотрудника</a>
    <table border="1">
        <thead>
            <tr>
                <th>ФИО</th>
                <th>Дата рождения</th>
                <th>Паспорт</th>
                <th>Контакты</th>
                <th>Адрес</th>
                <th>Отдел</th>
                <th>Должность</th>
                <th>Зарплата</th>
                <th>Дата принятия</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['full_name']) ?></td>
                        <td><?= htmlspecialchars($row['birth_date']) ?></td>
                        <td><?= htmlspecialchars($row['passport_number']) ?></td>
                        <td><?= htmlspecialchars($row['contact_info']) ?></td>
                        <td><?= htmlspecialchars($row['address']) ?></td>
                        <td><?= htmlspecialchars($row['department']) ?></td>
                        <td><?= htmlspecialchars($row['position']) ?></td>
                        <td><?= htmlspecialchars($row['salary']) ?></td>
                        <td><?= htmlspecialchars($row['hire_date']) ?></td>
                        <td>
                            <a href="edit.php?id=<?= $row['id'] ?>">Редактировать</a>
                            <a href="fire.php?id=<?= $row['id'] ?>">Уволить</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="10">Нет активных сотрудников</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>

<?php
$conn->close();
?>
