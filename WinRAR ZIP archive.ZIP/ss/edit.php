<?php
include 'db.php';

$id = $_GET['id'];
$sql = "SELECT * FROM employees WHERE id = $id";
$result = $conn->query($sql);
$employee = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $birth_date = $_POST['birth_date'];
    $passport_number = $_POST['passport_number'];
    $contact_info = $_POST['contact_info'];
    $address = $_POST['address'];
    $department = $_POST['department'];
    $position = $_POST['position'];
    $salary = $_POST['salary'];
    $hire_date = $_POST['hire_date'];

    $sql = "UPDATE employees SET 
            full_name='$full_name', 
            birth_date='$birth_date', passport_number='$passport_number', contact_info='$contact_info', address='$address', department='$department', position='$position', salary='$salary', hire_date='$hire_date' WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        header('Location: index.php');
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Редактировать сотрудника</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Редактировать сотрудника</h1>
    <form method="post" action="edit.php?id=<?= $id ?>">
        <label>ФИО: <input type="text" name="full_name" value="<?= htmlspecialchars($employee['full_name']) ?>" required></label><br>
        <label>Дата рождения: <input type="date" name="birth_date" value="<?= htmlspecialchars($employee['birth_date']) ?>" required></label><br>
        <label>Паспорт: <input type="text" name="passport_number" value="<?= htmlspecialchars($employee['passport_number']) ?>" required></label><br>
        <label>Контакты: <input type="text" name="contact_info" value="<?= htmlspecialchars($employee['contact_info']) ?>"></label><br>
        <label>Адрес: <input type="text" name="address" value="<?= htmlspecialchars($employee['address']) ?>"></label><br>
        <label>Отдел: <input type="text" name="department" value="<?= htmlspecialchars($employee['department']) ?>"></label><br>
        <label>Должность: <input type="text" name="position" value="<?= htmlspecialchars($employee['position']) ?>"></label><br>
        <label>Зарплата: <input type="number" step="0.01" name="salary" value="<?= htmlspecialchars($employee['salary']) ?>"></label><br>
        <label>Дата принятия: <input type="date" name="hire_date" value="<?= htmlspecialchars($employee['hire_date']) ?>" required></label><br>
        <input type="submit" value="Сохранить изменения">
    </form>
    <a href="index.php">Назад к списку сотрудников</a>
</body>
</html>
