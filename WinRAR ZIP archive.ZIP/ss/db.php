<?php
$host = 'localhost';
$db = 'employes_db';
$user = 'root'; // Замените на ваше имя пользователя
$pass = ''; // Замените на ваш пароль

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
