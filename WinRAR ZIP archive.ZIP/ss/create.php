<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $birth_date = $_POST['birth_date'];
    $passport_number = $_POST['passport_number'];
    $contact_info = $_POST['contact_info'];
    $address = $_POST['address'];
    $department = $_POST['department'];
    $position = $_POST['position'];
    $salary = $_POST['salary'];
    $hire_date = $_POST['hire_date'];

    $sql = "INSERT INTO employees (full_name, birth_date, passport_number, contact_info, address, department, position, salary, hire_date) VALUES ('$full_name', '$birth_date', '$passport_number', '$contact_info', '$address', '$department', '$position', '$salary', '$hire_date')";

    if ($conn->query($sql) === TRUE) {
        header('Location: index.php');
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Добавить сотрудника</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Добавить нового сотрудника</h1>
    <form method="post" action="create.php">
        <label>ФИО: <input type="text" name="full_name" required></label><br>
        <label>Дата рождения: <input type="date" name="birth_date" required></label><br>
        <label>Паспорт: <input type="text" name="passport_number" required></label><br>
        <label>Контакты: <input type="text" name="contact_info"></label><br>
        <label>Адрес: <input type="text" name="address"></label><br>
        <label>Отдел: <input type="text" name="department"></label><br>
        <label>Должность: <input type="text" name="position"></label><br>
        <label>Зарплата: <input type="number" step="0.01" name="salary"></label><br>
        <label>Дата принятия: <input type="date" name="hire_date" required></label><br>
        <input type="submit" value="Добавить">
    </form>
    <a href="index.php">Назад к списку сотрудников</a>
</body>
</html>
